#!/bin/bash
## TO USE THIS SCRIPT, issue -- 
## source /software/miniconda3/bin/activate apps

function get_sdf_from_mol2_rdkit {
	cat << EOF > get_sdf_from_mol2_rdkit.py
#!/usr/bin/env python3

import sys
import rdkit
import rdkit.Chem.rdmolfiles
from rdkit.Chem.rdmolfiles import SmilesWriter
from rdkit.Chem.rdmolfiles import SDWriter
import rdkit.Chem.Draw
from rdkit.Chem.Draw import MolToFile
from rdkit.Chem.Draw import rdMolDraw2D
import rdkit.Chem.rdDepictor
from rdkit.Chem.rdDepictor import Compute2DCoords
import rdkit.Chem
from rdkit.Chem import MolFromSmiles


if __name__ == "__main__":

    import argparse
    from collections import defaultdict as ddict

    parser = argparse.ArgumentParser \
    ( formatter_class=argparse.RawDescriptionHelpFormatter,
      description="""
      """,
      epilog="""

""")


    parser.add_argument \
        ("-m","--mol2",
        help="mol2 file",
        type=str,
        required=True )

    parser.add_argument \
        ("-o","--out",
        help="output sdf file",
        type=str,
        required=False )


    args = parser.parse_args()



    p = rdkit.Chem.MolFromMol2File(args.mol2, removeHs=False)
    writer = SDWriter("%s"%(args.out))
    writer.write(p)
EOF
	chmod a+x get_sdf_from_mol2_rdkit.py
	./get_sdf_from_mol2_rdkit.py -m $1 -o $2
	rm -rf get_sdf_from_mol2_rdkit.py
}

# MAIN
if [ $# -eq 0 ]; then printf "%s \n" "Provide ligand pdb file" && exit 0; fi

antechamber -i $1 -fi pdb -o ligand.mol2 -fo mol2 -at sybyl -pf y
get_sdf_from_mol2_rdkit "ligand.mol2" "ligand.sdf"
