#!/bin/bash
top=${PWD}
lig=(TH-Z801 TH-Z816 TH-Z827mod TH-Z835mod TH-Z837mod)

for l in ${lig[@]}; do
    sed -i -e "s/obj03/${l}/" ${l}/ligand.sdf
done
