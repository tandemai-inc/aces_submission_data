#!/bin/bash
top=${PWD}
lig=$(find . -mindepth 1 -maxdepth 1 -type d -printf "%f\n")

for l in ${lig[@]}; do
    cd ${l}
    sh ../get_sdf_from_pdb.sh ligand.pdb
    cd ${top}
done
